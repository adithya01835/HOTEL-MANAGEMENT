from flask import Flask, render_template, request, redirect, url_for, flash
import mysql.connector
from datetime import datetime 

app = Flask(__name__)
app.secret_key = 'supersecret123'

# ✅ Database Connection Function
def get_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="Adithya@123",  # Change this if needed
        database="hotel_db"
    )

# ✅ Home Page Route
@app.route('/')
def home():
    return render_template("index.html")

# ✅ Book a Room Route
@app.route('/book_room', methods=['POST'])
def book_room():
    name = request.form['name']
    phone = request.form['phone']
    email = request.form['email']
    room_ids = request.form['room_ids'].split(',')
    checkin = request.form['checkin_date']
    checkout = request.form['checkout_date']

    conn = get_connection()
    cursor = conn.cursor()

    booked_rooms = []
    unavailable_rooms = []

    for room_id in room_ids:
        room_id = room_id.strip()
        cursor.execute("SELECT is_available FROM rooms WHERE room_id=%s", (room_id,))
        status = cursor.fetchone()

        if status and status[0]:  # Room is available
            cursor.execute("""
                INSERT INTO bookings (name, phone, email, room_id, checkin_date, checkout_date)
                VALUES (%s, %s, %s, %s, %s, %s)
            """, (name, phone, email, room_id, checkin, checkout))

            cursor.execute("UPDATE rooms SET is_available=FALSE WHERE room_id=%s", (room_id,))
            booked_rooms.append(room_id)
        else:
            unavailable_rooms.append(room_id)

    conn.commit()
    cursor.close()
    conn.close()

    # Flash appropriate message
    if booked_rooms:
        flash(f"✅ Rooms booked successfully: {', '.join(booked_rooms)}")
    if unavailable_rooms:
        flash(f"❌ These rooms were unavailable or invalid: {', '.join(unavailable_rooms)}")

    return redirect(url_for('home'))

# ✅ Checkout Route
@app.route('/checkout', methods=['POST'])
def checkout():
    room_id = request.form['room_id']
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE rooms SET is_available=TRUE WHERE room_id=%s", (room_id,))
    conn.commit()
    cursor.close()
    conn.close()
    flash(f"✅ Room {room_id} checked out successfully.")
    return redirect(url_for('home'))
 
# ✅ View Available Rooms
@app.route('/view_rooms')
def view_rooms():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM rooms WHERE is_available=TRUE")
    rooms = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template("rooms.html", rooms=rooms)

# ✅ View All Bookings
@app.route('/view_bookings')
def view_bookings():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM bookings")
    bookings = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template("bookings.html", bookings=bookings)

# ✅ Search Guest by Phone
@app.route('/search_guest')
def search_guest():
    phone = request.args.get('phone')
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM bookings WHERE phone=%s", (phone,))
    guest = cursor.fetchone()
    cursor.close()
    conn.close()

    if guest:
        return render_template("search_result.html", guest=guest)
    else:
        return render_template("search_result.html", message="❌ No guest found with this phone number.")

# ✅ Show Bill for a Room
@app.route('/show_bill')
def show_bill():
    room_id = request.args.get('room_id')
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT checkin_date, checkout_date
        FROM bookings
        WHERE room_id=%s
        ORDER BY BookingID DESC
        LIMIT 1
    """, (room_id,))
    row = cursor.fetchone()
    cursor.close()
    conn.close()

    if row:
        checkin_date = datetime.strptime(str(row[0]), '%Y-%m-%d')
        checkout_date = datetime.strptime(str(row[1]), '%Y-%m-%d')
        days = max((checkout_date - checkin_date).days, 1)
        rate_per_day = 1000
        total_bill = days * rate_per_day
        flash(f"💰 Bill for Room {room_id} is ₹{total_bill}")
    else:
        flash("❌ No booking found for this room.")

    return redirect(url_for('home'))

@app.route('/test')
def test():
    return render_template("test.html")

# ✅ Start the App
if __name__ == '__main__':
    app.run(debug=True)